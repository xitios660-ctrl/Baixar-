# Mantém os nomes que aparecem nas pilhas de erro enviadas ao Saimo Monitor.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
# OkHttp e Coil trazem as próprias regras; estas silenciam avisos de
# dependências opcionais que o app não usa.
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
# Log de depuração não vai para o APK publicado: cada um custava montar a
# string a cada troca de canal, para ninguém ler. Avisos e erros ficam.
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
}

-keepclassmembers class br.com.saimo.tv.** { public void guhflixInitialize(android.os.Bundle); }
# Branding uses reflective activity fields; preserve names through release R8.
-keep class com.guhflix.shell.** { *; }
-keep class br.com.saimo.tv.*Activity { *; }

# apksig reads ASN.1/PKCS#7 models by reflection. Removing annotations or fields
# makes the release updater reject correctly signed APKs (debug is unaffected).
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.android.apksig.** { *; }

package br.com.saimo.tv

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil3.dispose
import coil3.load
import kotlinx.coroutines.launch

/**
 * Fileiras de capa, como numa TV: a tela inicial, os resultados da busca.
 *
 * O peso foi o que mandou no desenho. Um TV Box de 2016 não aguenta dezenas de
 * imagens grandes:
 *
 * - as capas já chegam resolvidas (destaques, fichas), sem consulta ao TMDB;
 * - as fileiras dividem um só depósito de células;
 * - cada célula tem tamanho fixo, então nada pula enquanto as imagens chegam;
 * - as capas ficam em disco: rolar para baixo e voltar não baixa de novo.
 */
object Inicio {

    /// A fileira do último cartão focado: rolar a tela só quando ela muda.
    private var ultimaFileira = java.lang.ref.WeakReference<View>(null)

    /**
     * Um item da fileira.
     *
     * A ação vem junto de propósito: a fileira não sabe se aquilo é um filme,
     * uma série, um canal ou um atalho — ela desenha e chama.
     */
    data class Cartao(
        val titulo: String,
        /// Vazio quando não há imagem: aí a inicial preenche o quadro.
        val capa: String,
        val inicial: String,
        /// Quanto já foi visto, de 0 a 1. Nulo quando nunca foi aberto.
        val progresso: Float? = null,
        /// Quando não veio capa pronta, diz se vale procurar uma e se é série.
        val procurarCapa: Boolean? = null,
        /// O nome com que se procura a capa, quando não é o que está no cartão.
        val nomeDaCapa: String? = null,
        /// Linha de baixo do cartão largo (o programa no ar, no canal).
        val subtitulo: String? = null,
        /** Trailer direto do banner, quando publicado no catálogo. */
        val trailer: String? = null,
        /// O título por trás do cartão, para o destaque do topo e o MENU.
        val alvo: Alvo? = null,
        /// MENU sobre o cartão: favoritar, tirar do "continuar"...
        val aoMenu: (() -> Unit)? = null,
        /// Cartão de categoria: as capas da colagem, o ícone e a cor dela.
        val colagem: List<String> = emptyList(),
        val icone: Int = 0,
        val cor: Int = 0,
        /// Linha de cima e texto do destaque quando o cartão não é um título.
        val meta: String? = null,
        val sinopse: String? = null,
        /// Título cuja imagem larga vai ao fundo do destaque, quando o cartão
        /// não é ele mesmo um título (a categoria mostra o filme em alta).
        val fundoDe: Alvo? = null,
        /// Cartão de jogo: o selo do canto (placar ao vivo ou horário).
        val selo: String? = null,
        val seloAoVivo: Boolean = false,
        val aoEscolher: () -> Unit,
    )

    enum class Tipo { CAPA, LARGO, SECAO, EVENTO }

    /**
     * O gerente da lista de fileiras: não rola sozinho quando o foco muda.
     *
     * O padrão do RecyclerView rola até o cartão focado caber inteiro — e com
     * o respiro de baixo, o cartão da fileira de baixo nunca cabia, então cada
     * passo para o lado sacudia a tela inteira. Quem rola agora é o foco
     * trocar de fileira, e só ele.
     */
    class Filas(context: android.content.Context) : LinearLayoutManager(context) {
        override fun requestChildRectangleOnScreen(
            parent: RecyclerView, child: View, rect: android.graphics.Rect, immediate: Boolean,
        ) = false

        override fun requestChildRectangleOnScreen(
            parent: RecyclerView, child: View, rect: android.graphics.Rect, immediate: Boolean,
            focusedChildVisible: Boolean,
        ) = false
    }

    data class Fila(
        val titulo: String,
        val cartoes: List<Cartao>,
        val tipo: Tipo = Tipo.CAPA,
        /// Se as fichas já estavam na memória quando a fileira foi montada: a
        /// capa de quem não traz a própria sai delas na hora de desenhar, e a
        /// fileira montada antes delas tem de ser redesenhada quando chegam.
        val comFichas: Boolean = Generos.prontos,
    )

    class Adapter(
        private val escopo: kotlinx.coroutines.CoroutineScope? = null,
        private val capaDe: (suspend (String, Boolean) -> String?)? = null,
        /// Chamado quando um cartão ganha o foco — é o que troca o destaque.
        private val aoFocar: ((Cartao) -> Unit)? = null,
    ) : RecyclerView.Adapter<Adapter.Holder>() {

        private var filas: List<Fila> = emptyList()
        private val depositoCapas = RecyclerView.RecycledViewPool()
        private val depositoLargos = RecyclerView.RecycledViewPool()
        private val depositoSecoes = RecyclerView.RecycledViewPool()
        private val depositoEventos = RecyclerView.RecycledViewPool()
        /// Onde cada fileira estava, para voltar no mesmo lugar.
        private val posicoes = mutableMapOf<String, Int>()

        /**
         * Troca as fileiras mexendo só no que mudou.
         *
         * Redesenhar tudo recriava as capas e o foco de quem estava navegando
         * escapava para o menu — acontecia quando as fileiras de gênero ou o
         * guia chegavam segundos depois da tela abrir.
         */
        fun trocar(novas: List<Fila>) {
            val velhas = filas
            filas = novas
            if (velhas.isEmpty()) { notifyDataSetChanged(); return }
            val comum = minOf(velhas.size, novas.size)
            for (i in 0 until comum) {
                val a = velhas[i]; val b = novas[i]
                val igual = a.titulo == b.titulo && a.tipo == b.tipo && a.comFichas == b.comFichas &&
                    a.cartoes.size == b.cartoes.size &&
                    a.cartoes.indices.all { a.cartoes[it].titulo == b.cartoes[it].titulo &&
                        a.cartoes[it].subtitulo == b.cartoes[it].subtitulo &&
                        a.cartoes[it].selo == b.cartoes[it].selo &&
                        a.cartoes[it].progresso == b.cartoes[it].progresso }
                if (!igual) notifyItemChanged(i)
            }
            if (novas.size > velhas.size) notifyItemRangeInserted(velhas.size, novas.size - velhas.size)
            else if (novas.size < velhas.size) notifyItemRangeRemoved(novas.size, velhas.size - novas.size)
        }

        inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val titulo: TextView = view.findViewById(R.id.filaTitulo)
            val capas: RecyclerView = view.findViewById(R.id.filaCapas)
        }

        override fun getItemViewType(position: Int) = filas[position].tipo.ordinal

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val holder = Holder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_fila, parent, false))
            holder.capas.layoutManager =
                LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false).apply {
                    initialPrefetchItemCount = 6
                }
            holder.capas.setRecycledViewPool(when (viewType) {
                Tipo.LARGO.ordinal -> depositoLargos
                Tipo.SECAO.ordinal -> depositoSecoes
                Tipo.EVENTO.ordinal -> depositoEventos
                else -> depositoCapas
            })
            holder.capas.isFocusable = false
            return holder
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val fila = filas[position]
            holder.titulo.text = fila.titulo
            holder.capas.adapter = Capas(fila.cartoes, fila.tipo, escopo, capaDe, aoFocar)
            holder.capas.scrollToPosition(posicoes[fila.titulo] ?: 0)
            holder.capas.clearOnScrollListeners()
            holder.capas.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                    val gerente = rv.layoutManager as? LinearLayoutManager ?: return
                    posicoes[fila.titulo] = gerente.findFirstVisibleItemPosition()
                }
            })
        }

        override fun getItemCount() = filas.size
    }

    /** As capas de uma fileira. */
    private class Capas(
        private val cartoes: List<Cartao>,
        private val tipo: Tipo,
        private val escopo: kotlinx.coroutines.CoroutineScope?,
        private val capaDe: (suspend (String, Boolean) -> String?)?,
        private val aoFocar: ((Cartao) -> Unit)?,
    ) : RecyclerView.Adapter<Capas.Holder>() {

        class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val imagem: ImageView = view.findViewById(R.id.capaImagem)
            val inicial: TextView = view.findViewById(R.id.capaInicial)
            val nome: TextView = view.findViewById(R.id.capaNome)
            val sub: TextView? = view.findViewById(R.id.capaSub)
            val progresso: ProgressBar = view.findViewById(R.id.capaProgresso)
            val colagem: List<ImageView> = listOfNotNull(
                view.findViewById(R.id.secaoCapa1), view.findViewById(R.id.secaoCapa2),
                view.findViewById(R.id.secaoCapa3), view.findViewById(R.id.secaoCapa4))
            val icone: ImageView? = view.findViewById(R.id.secaoIcone)
            val cor: View? = view.findViewById(R.id.secaoCor)
            val casa: ImageView? = view.findViewById(R.id.eventoCasa)
            val fora: ImageView? = view.findViewById(R.id.eventoFora)
            val liga: ImageView? = view.findViewById(R.id.eventoLiga)
            val selo: TextView? = view.findViewById(R.id.eventoSelo)
            var pedido: String? = null
            var cartao: Cartao? = null
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val layout = when (tipo) {
                Tipo.LARGO -> R.layout.item_cartao_largo
                Tipo.SECAO -> R.layout.item_secao
                Tipo.EVENTO -> R.layout.item_evento_cartao
                else -> R.layout.item_capa
            }
            val holder = Holder(LayoutInflater.from(parent.context).inflate(layout, parent, false))
            Cartoes.arredondar(holder.imagem.parent as View)
            // Sem crescer no foco: o contorno do row_focus já mostra onde está,
            // e a capa aumentando empurrava as vizinhas a cada passo.
            holder.itemView.setOnFocusChangeListener { view, focado ->
                if (!focado) return@setOnFocusChangeListener
                holder.cartao?.let { aoFocar?.invoke(it) }
                // A fileira inteira à vista, com o nome dela — só quando o foco
                // chega de outra fileira. Andar para o lado não mexe na tela.
                val fileira = view.parent?.let { it as? View }?.parent as? View ?: return@setOnFocusChangeListener
                if (fileira === ultimaFileira.get()) return@setOnFocusChangeListener
                ultimaFileira = java.lang.ref.WeakReference(fileira)
                // A fileira nova sobe para o topo da lista, sempre no mesmo lugar.
                val lista = fileira.parent as? RecyclerView ?: return@setOnFocusChangeListener
                lista.post { lista.smoothScrollBy(0, fileira.top - lista.paddingTop) }
            }
            holder.itemView.setOnKeyListener { _, codigo, evento ->
                if (Cartoes.segurarNasPontas(holder, codigo, evento)) return@setOnKeyListener true
                if (evento.action == KeyEvent.ACTION_DOWN &&
                    (codigo == KeyEvent.KEYCODE_MENU || codigo == KeyEvent.KEYCODE_BOOKMARK)) {
                    holder.cartao?.aoMenu?.let { it(); true } ?: false
                } else false
            }
            holder.itemView.setOnLongClickListener { holder.cartao?.aoMenu?.let { it(); true } ?: false }
            return holder
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val cartao = cartoes[position]
            holder.cartao = cartao
            holder.nome.text = cartao.titulo
            holder.sub?.text = cartao.subtitulo.orEmpty()
            holder.inicial.text = cartao.inicial
            holder.itemView.setOnClickListener { cartao.aoEscolher() }

            if (tipo == Tipo.SECAO) { secao(holder, cartao); return }
            if (tipo == Tipo.EVENTO) { evento(holder, cartao); return }

            holder.progresso.visibility =
                if (cartao.progresso == null || cartao.progresso <= 0f) View.GONE else View.VISIBLE
            cartao.progresso?.let { holder.progresso.progress = (it * 1000).toInt() }

            holder.imagem.dispose()
            holder.imagem.setImageDrawable(null)
            holder.inicial.visibility = View.VISIBLE
            holder.pedido = cartao.titulo
            val direta = cartao.capa.ifEmpty {
                // Sem capa pronta: o arquivo de fichas quase sempre sabe, e em
                // memória — sem ir à rede.
                val serie = cartao.procurarCapa
                if (serie != null) Generos.capa(cartao.nomeDaCapa ?: cartao.titulo, serie).orEmpty() else ""
            }
            if (direta.isEmpty()) {
                holder.imagem.visibility = View.GONE
                val serie = cartao.procurarCapa ?: return
                val buscar = capaDe ?: return
                val nome = cartao.nomeDaCapa ?: cartao.titulo
                escopo?.launch {
                    val achada = buscar(nome, serie) ?: return@launch
                    if (holder.pedido != cartao.titulo) return@launch
                    Cartoes.carregar(holder.imagem, holder.inicial, achada)
                }
                return
            }
            Cartoes.carregar(holder.imagem, holder.inicial, direta)
        }

        /** Cartão de jogo: escudos (colagem = casa, fora, campeonato) e o selo. */
        private fun evento(holder: Holder, cartao: Cartao) {
            listOf(holder.casa, holder.fora, holder.liga).forEachIndexed { i, imagem ->
                imagem ?: return@forEachIndexed
                imagem.dispose()
                imagem.setImageDrawable(null)
                cartao.colagem.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { imagem.load(it) }
            }
            holder.selo?.apply {
                text = cartao.selo.orEmpty()
                visibility = if (cartao.selo.isNullOrEmpty()) View.GONE else View.VISIBLE
                setBackgroundResource(if (cartao.seloAoVivo) R.drawable.bg_chip else R.drawable.bg_chip_neutro)
            }
        }

        /** Cartão de categoria: colagem de capas, cor e ícone da categoria. */
        private fun secao(holder: Holder, cartao: Cartao) {
            holder.colagem.forEachIndexed { i, imagem ->
                imagem.dispose()
                imagem.setImageDrawable(null)
                cartao.colagem.getOrNull(i)?.let { imagem.load(it) }
            }
            // A cor entra pelo canto de baixo e some antes do meio do cartão.
            holder.cor?.background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BL_TR,
                intArrayOf(cartao.cor and 0x00FFFFFF or (0xB3 shl 24), cartao.cor and 0x00FFFFFF),
            )
            holder.icone?.apply {
                setImageResource(cartao.icone)
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(cartao.cor)
                }
                imageTintList = android.content.res.ColorStateList.valueOf(0xFF0B0E14.toInt())
            }
        }

        override fun getItemCount() = cartoes.size
    }
}

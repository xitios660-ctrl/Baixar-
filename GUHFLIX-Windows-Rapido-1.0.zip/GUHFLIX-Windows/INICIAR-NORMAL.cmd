@echo off
setlocal
cd /d "%~dp0"
set "SAIMO_MPV="
set "GUHFLIX_STARTUP_MODE="
start "" "%~dp0Saimo TV.exe"
endlocal

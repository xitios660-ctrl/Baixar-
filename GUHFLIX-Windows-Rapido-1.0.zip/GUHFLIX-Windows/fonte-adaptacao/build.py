from pathlib import Path
import argparse,os,subprocess,shutil
p=argparse.ArgumentParser();p.add_argument('--zig',required=True);p.add_argument('--original-lib',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(__file__).resolve().parent;out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
subprocess.run([a.zig,'cc','-target','x86_64-windows-gnu','-shared','-O2','-Wall','-Wextra',str(root/'mpv_startup.c'),str(root/'exports.def'),'-o',str(out/'guhflix-mpv.dll'),'-lkernel32'],check=True)
subprocess.run(['python3',str(root/'fix_export_ordinals.py'),str(out/'guhflix-mpv.dll'),a.original_lib],check=True)
print('Built Windows x64 DLL. Requires original libmpv-2.dll alongside application; launch with SAIMO_MPV pointing to the DLL and GUHFLIX_STARTUP_MODE=fast.')

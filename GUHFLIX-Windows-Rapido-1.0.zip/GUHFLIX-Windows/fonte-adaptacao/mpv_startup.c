#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "startup_policy.h"
static INIT_ONCE once=INIT_ONCE_STATIC_INIT;
static HMODULE original;
static set_option_fn set_option;
static initialize_fn initialize;
static BOOL CALLBACK load_original(PINIT_ONCE init,PVOID parameter,PVOID *context){
 (void)init;(void)parameter;(void)context;
 WCHAR path[32768];DWORD n=GetModuleFileNameW(NULL,path,32768);
 if(!n||n>=32768)return FALSE;
 while(n&&path[n-1]!=L'\\'&&path[n-1]!=L'/')n--;
 if(!n||n+13>=32768)return FALSE;
 lstrcpyW(path+n,L"libmpv-2.dll");
 original=LoadLibraryExW(path,NULL,LOAD_WITH_ALTERED_SEARCH_PATH);
 if(!original)return FALSE;
 set_option=(set_option_fn)GetProcAddress(original,"mpv_set_option_string");
 initialize=(initialize_fn)GetProcAddress(original,"mpv_initialize");
 if(!set_option||!initialize){FreeLibrary(original);original=NULL;return FALSE;}
 return TRUE;
}
int mpv_initialize(void *handle){
 if(!InitOnceExecuteOnce(&once,load_original,NULL,NULL))return -3;
 WCHAR mode[16];DWORD n=GetEnvironmentVariableW(L"GUHFLIX_STARTUP_MODE",mode,16);
 int fast=n==4&&mode[0]==L'f'&&mode[1]==L'a'&&mode[2]==L's'&&mode[3]==L't';
 return startup_initialize(handle,set_option,initialize,fast);
}

#ifndef GUHFLIX_STARTUP_POLICY_H
#define GUHFLIX_STARTUP_POLICY_H
typedef int (*set_option_fn)(void*,const char*,const char*);
typedef int (*initialize_fn)(void*);
/* Only initial cache gating; rebuffer policy/quality/network security untouched. */
static int startup_initialize(void *handle,set_option_fn set_option,initialize_fn initialize,int fast){
 if(fast)set_option(handle,"cache-pause-initial","no");
 return initialize(handle);
}
#endif

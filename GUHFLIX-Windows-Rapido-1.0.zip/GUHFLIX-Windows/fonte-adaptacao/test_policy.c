#include <assert.h>
#include <string.h>
#include "startup_policy.h"
static int sequence,options,inits,fail_option;
static void *expected=(void*)0x1234;
static int option(void*h,const char*k,const char*v){assert(h==expected);assert(sequence==0);sequence=1;options++;assert(!strcmp(k,"cache-pause-initial"));assert(!strcmp(v,"no"));return fail_option?-8:0;}
static int init(void*h){assert(h==expected);assert(sequence==options);inits++;sequence=2;return -12;}
int main(void){
 assert(startup_initialize(expected,option,init,1)==-12);assert(options==1&&inits==1);
 sequence=options=inits=0;assert(startup_initialize(expected,option,init,0)==-12);assert(options==0&&inits==1);
 sequence=options=inits=0;fail_option=1;assert(startup_initialize(expected,option,init,1)==-12);assert(inits==1);
 return 0;
}

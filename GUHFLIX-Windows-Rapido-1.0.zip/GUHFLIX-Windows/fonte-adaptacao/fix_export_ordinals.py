"""Preserve the upstream API's numbered exports after LLVM MinGW forwarding."""
import struct,subprocess,re,sys
from pathlib import Path
proxy=Path(sys.argv[1]);original=Path(sys.argv[2]);b=bytearray(proxy.read_bytes())
pe=struct.unpack_from('<I',b,0x3c)[0];assert b[pe:pe+4]==b'PE\0\0'
sections=struct.unpack_from('<H',b,pe+6)[0];optsize=struct.unpack_from('<H',b,pe+20)[0];opt=pe+24;assert struct.unpack_from('<H',b,opt)[0]==0x20b
sec=opt+optsize
def offset(rva):
 for i in range(sections):
  s=sec+i*40;vs,va,rawsize,raw=struct.unpack_from('<IIII',b,s+8)
  if va<=rva<va+max(vs,rawsize):return raw+rva-va
 raise ValueError('InvalidRVA')
export=offset(struct.unpack_from('<I',b,opt+112)[0]);base,nfunc,nnames,eat,names,ords=struct.unpack_from('<IIIIII',b,export+16)
eat,names,ords=map(offset,[eat,names,ords]);addresses=list(struct.unpack_from('<'+'I'*nfunc,b,eat));mapping={}
for i in range(nnames):
 pos=offset(struct.unpack_from('<I',b,names+i*4)[0]);end=b.index(0,pos);name=b[pos:end].decode();idx=struct.unpack_from('<H',b,ords+i*2)[0];mapping[name]=(i,addresses[idx])
s=subprocess.check_output(['objdump','-p',str(original)],text=True).split('[Ordinal/Name Pointer] Table',1)[1].split('The Function Table',1)[0]
expected={name:int(o) for o,name in re.findall(r'\[\s*\d+\] \+base\[\s*(\d+)\]\s+[0-9a-f]+ (\S+)',s)}
assert set(expected)==set(mapping) and nfunc==len(expected) and set(expected.values())==set(range(1,nfunc+1))
for name,ordinal in expected.items():
 index,address=mapping[name];struct.pack_into('<I',b,eat+(ordinal-1)*4,address);struct.pack_into('<H',b,ords+index*2,ordinal-1)
struct.pack_into('<I',b,export+16,1)
# User-mode DLL; clear obsolete optional checksum (the DLL is unsigned).
struct.pack_into('<I',b,opt+64,0);proxy.write_bytes(b)

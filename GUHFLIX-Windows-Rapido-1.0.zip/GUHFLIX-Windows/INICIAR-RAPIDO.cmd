@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Saimo TV.exe" exit /b 1
if not exist "%~dp0libmpv-2.dll" exit /b 1
set "SAIMO_MPV=%~dp0guhflix-mpv.dll"
set "GUHFLIX_STARTUP_MODE=fast"
start "" "%~dp0Saimo TV.exe"
endlocal

//! Player de vídeo: o mpv, carregado da DLL que vai junto no pacote.
//!
//! A imagem não vai para uma janela do mpv: ele desenha dentro do mesmo
//! framebuffer OpenGL da interface (API de render do libmpv), e a lista de
//! canais é desenhada por cima. Sem isso seriam duas janelas disputando a tela.
//!
//! As funções são resolvidas em tempo de execução (`libloading`), então não é
//! preciso biblioteca de importação do mpv para compilar do Mac para o Windows.

use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};

#[allow(non_camel_case_types)]
type mpv_handle = c_void;
#[allow(non_camel_case_types)]
type mpv_render_context = c_void;

static HWDEC: std::sync::OnceLock<&'static str> = std::sync::OnceLock::new();

/// Decodificação por hardware que o mpv vai pedir. Dita pela placa (ver `main.rs`) e, depois de uma
/// queda, pelo modo seguro: nenhuma, decodificando no processador.
pub fn preferir_hwdec(valor: &'static str) {
    let _ = HWDEC.set(valor);
}

fn hwdec_escolhido() -> &'static str {
    if crate::diagnostico::nivel() >= 1 {
        return "no";
    }
    HWDEC.get().copied().unwrap_or("auto-copy-safe")
}

#[repr(C)]
struct MpvRenderParam {
    tipo: c_int,
    dados: *mut c_void,
}

#[repr(C)]
struct MpvOpenGLInitParams {
    get_proc_address: extern "C" fn(*mut c_void, *const c_char) -> *mut c_void,
    get_proc_address_ctx: *mut c_void,
}

#[repr(C)]
struct MpvOpenGLFbo {
    fbo: c_int,
    w: c_int,
    h: c_int,
    internal_format: c_int,
}

#[repr(C)]
struct MpvEvent {
    event_id: c_int,
    error: c_int,
    reply_userdata: u64,
    data: *mut c_void,
}

#[repr(C)]
struct MpvEventEndFile {
    reason: c_int,
    error: c_int,
    /// Qual item da playlist acabou (libmpv 0.33+).
    playlist_entry_id: i64,
}

#[repr(C)]
struct MpvEventStartFile {
    playlist_entry_id: i64,
}

const PARAM_INVALID: c_int = 0;
const PARAM_API_TYPE: c_int = 1;
const PARAM_OPENGL_INIT_PARAMS: c_int = 2;
const PARAM_OPENGL_FBO: c_int = 3;
const PARAM_FLIP_Y: c_int = 4;

#[repr(C)]
struct MpvEventLogMessage {
    prefix: *const c_char,
    level: *const c_char,
    text: *const c_char,
    log_level: c_int,
}
const EVENT_SHUTDOWN: c_int = 1;
const EVENT_LOG_MESSAGE: c_int = 2;
const EVENT_START_FILE: c_int = 6;
const EVENT_END_FILE: c_int = 7;
const EVENT_FILE_LOADED: c_int = 8;
const EVENT_PLAYBACK_RESTART: c_int = 21;
const END_FILE_EOF: c_int = 0;
const END_FILE_ERROR: c_int = 4;

/// O que a tela precisa saber do player, sem falar C.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Aviso {
    /// O arquivo abriu e o vídeo começou.
    Tocando,
    /// A fonte morreu: hora de tentar a próxima.
    Falhou,
    /// Acabou sozinho (VOD) ou o servidor cortou.
    Fim,
}

/// Decide o que um fim de arquivo significa.
///
/// O `loadfile replace` encerra o arquivo anterior com motivo STOP, e esse
/// aviso chega depois que a fonte nova já começou. Tratado como "fim", ele
/// derrubava a fonte nova, que derrubava a seguinte — e o canal passava por
/// todas as fontes em um segundo e dizia que estava fora do ar. Agora só conta
/// o fim do arquivo que está de fato no ar, e só por erro ou fim de verdade.
#[derive(Default)]
pub struct Vigia {
    atual: Option<i64>,
}

impl Vigia {
    pub fn comecou(&mut self, item: i64) {
        self.atual = Some(item);
    }

    pub fn acabou(&mut self, item: i64, motivo: c_int) -> Option<Aviso> {
        // Fim de um arquivo que já foi substituído: aviso atrasado, ignora.
        if self.atual.is_some_and(|a| a != item) {
            return None;
        }
        match motivo {
            END_FILE_ERROR => Some(Aviso::Falhou),
            END_FILE_EOF => Some(Aviso::Fim),
            // STOP, QUIT e REDIRECT: foi o próprio app que trocou ou parou.
            _ => None,
        }
    }
}

struct Simbolos {
    _lib: libloading::Library,
    create: unsafe extern "C" fn() -> *mut mpv_handle,
    initialize: unsafe extern "C" fn(*mut mpv_handle) -> c_int,
    set_option_string: unsafe extern "C" fn(*mut mpv_handle, *const c_char, *const c_char) -> c_int,
    set_property_string: unsafe extern "C" fn(*mut mpv_handle, *const c_char, *const c_char) -> c_int,
    get_property_string: unsafe extern "C" fn(*mut mpv_handle, *const c_char) -> *mut c_char,
    free: unsafe extern "C" fn(*mut c_void),
    command: unsafe extern "C" fn(*mut mpv_handle, *const *const c_char) -> c_int,
    error_string: unsafe extern "C" fn(c_int) -> *const c_char,
    request_log_messages: unsafe extern "C" fn(*mut mpv_handle, *const c_char) -> c_int,
    wait_event: unsafe extern "C" fn(*mut mpv_handle, f64) -> *mut MpvEvent,
    wakeup: unsafe extern "C" fn(*mut mpv_handle),
    terminate_destroy: unsafe extern "C" fn(*mut mpv_handle),
    render_context_create:
        unsafe extern "C" fn(*mut *mut mpv_render_context, *mut mpv_handle, *mut MpvRenderParam) -> c_int,
    render_context_render: unsafe extern "C" fn(*mut mpv_render_context, *mut MpvRenderParam) -> c_int,
    render_context_free: unsafe extern "C" fn(*mut mpv_render_context),
}

/// Ponteiro do mpv atravessando threads: a API do libmpv é feita para isso.
struct Ponteiro(*mut mpv_handle);
unsafe impl Send for Ponteiro {}
unsafe impl Sync for Ponteiro {}

struct Render(*mut mpv_render_context);
unsafe impl Send for Render {}
unsafe impl Sync for Render {}

/// O número de cada mpv do app: o Saimo Connect usa para saber que lista
/// cada um está tocando.
static PROXIMO_ID: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);

pub struct Mpv {
    license: Option<Arc<crate::guhflix::Lease>>,
    alive: Arc<Mutex<bool>>,
    carregamento: Arc<crate::carregamento::Carregamento>,
    id: u64,
    simbolos: Arc<Simbolos>,
    handle: Arc<Ponteiro>,
    render: Mutex<Option<Render>>,
    erro_render: Mutex<Option<String>>,
    avisos: Receiver<Aviso>,
    _emissor: Sender<Aviso>,
    /// Pede à thread dos avisos que pare, antes de o handle ser destruído.
    parar_avisos: Arc<std::sync::atomic::AtomicBool>,
    thread_avisos: Mutex<Option<std::thread::JoinHandle<()>>>,
}

#[derive(Debug, Clone)]
pub struct Faixa {
    pub id: String,
    pub titulo: String,
    pub selecionada: bool,
}

// Ponteiros só são tocados por estes métodos, todos sincronizados pelo próprio
// libmpv, que é thread-safe.
unsafe impl Send for Mpv {}
unsafe impl Sync for Mpv {}

/// Endereço das funções de OpenGL, que no Windows moram em dois lugares: as do
/// OpenGL 1.1 na opengl32.dll e o resto no driver, via wglGetProcAddress.
extern "C" fn endereco_gl(_ctx: *mut c_void, nome: *const c_char) -> *mut c_void {
    #[cfg(windows)]
    unsafe {
        extern "system" {
            fn wglGetProcAddress(name: *const c_char) -> *mut c_void;
            fn LoadLibraryA(name: *const c_char) -> *mut c_void;
            fn GetProcAddress(modulo: *mut c_void, name: *const c_char) -> *mut c_void;
        }
        // O wglGetProcAddress não devolve só nulo quando não acha: a própria
        // documentação da Microsoft lista 1, 2, 3 e -1 como valores de falha.
        // O -1 passava pela conferência antiga e ia para o mpv como endereço
        // bom — e o mpv o chamava. Toda função do OpenGL 1.1 (glClear,
        // glViewport, glGetString) cai nesse caso em boa parte dos drivers.
        let falhou = |p: *mut c_void| {
            let valor = p as usize;
            p.is_null() || valor <= 3 || valor == usize::MAX
        };
        let achado = wglGetProcAddress(nome);
        if !falhou(achado) {
            return achado;
        }
        // LoadLibraryA e não GetModuleHandleA: se a opengl32 ainda não estiver
        // carregada no processo, o handle viria nulo e ficaria sem nada.
        let opengl32 = LoadLibraryA(b"opengl32.dll\0".as_ptr() as *const c_char);
        if opengl32.is_null() {
            return std::ptr::null_mut();
        }
        GetProcAddress(opengl32, nome)
    }
    // Fora do Windows o endereço sai do próprio processo: o OpenGL já está
    // carregado pela janela, e é assim que dá para rodar este mesmo caminho
    // aqui no Mac para conferir o desenho sem depender de uma máquina Windows.
    #[cfg(not(windows))]
    unsafe {
        extern "C" {
            fn dlsym(handle: *mut c_void, symbol: *const c_char) -> *mut c_void;
        }
        const RTLD_DEFAULT: *mut c_void = std::ptr::null_mut();
        dlsym(RTLD_DEFAULT, nome)
    }
}

impl Mpv {
    /// Carrega a DLL ao lado do executável e sobe um mpv sem janela própria.
    pub fn novo(caminho_da_dll: &std::path::Path) -> Result<Self, String> { Self::new_internal(caminho_da_dll,true) }
    pub fn novo_intro(caminho_da_dll: &std::path::Path) -> Result<Self, String> {Self::new_internal(caminho_da_dll,false)}
    fn new_internal(caminho_da_dll: &std::path::Path,protected:bool)->Result<Self,String>{
        Self::new_with_options(caminho_da_dll, protected, &[])
    }
    fn new_with_options(caminho_da_dll: &std::path::Path, protected: bool, extras: &[(&str, &str)]) -> Result<Self,String> {
        let simbolos = unsafe {
            let lib = libloading::Library::new(caminho_da_dll)
                .map_err(|e| format!("não achei o mpv ({}): {e}", caminho_da_dll.display()))?;
            macro_rules! pega {
                ($nome:literal) => {
                    *lib.get(concat!($nome, "\0").as_bytes())
                        .map_err(|e| format!("mpv sem {}: {e}", $nome))?
                };
            }
            Simbolos {
                create: pega!("mpv_create"),
                initialize: pega!("mpv_initialize"),
                set_option_string: pega!("mpv_set_option_string"),
                set_property_string: pega!("mpv_set_property_string"),
                get_property_string: pega!("mpv_get_property_string"),
                free: pega!("mpv_free"),
                command: pega!("mpv_command"),
                error_string: pega!("mpv_error_string"),
                request_log_messages: pega!("mpv_request_log_messages"),
                wait_event: pega!("mpv_wait_event"),
                wakeup: pega!("mpv_wakeup"),
                terminate_destroy: pega!("mpv_terminate_destroy"),
                render_context_create: pega!("mpv_render_context_create"),
                render_context_render: pega!("mpv_render_context_render"),
                render_context_free: pega!("mpv_render_context_free"),
                _lib: lib,
            }
        };
        let simbolos = Arc::new(simbolos);

        let handle = unsafe { (simbolos.create)() };
        if handle.is_null() {
            return Err("mpv_create falhou".into());
        }

        let opcoes = [
            // Sem janela própria: quem desenha é a API de render.
            ("vo", "libmpv"),
            // A API de render usa OpenGL/WGL. No Windows, decodificação
            // direta por D3D11 exige ANGLE; alguns drivers aceitam a faixa mas
            // entregam somente quadros pretos. O modo copy continua usando a
            // GPU para decodificar e traz o quadro para a memória antes de
            // desenhá-lo. Só a lista segura do mpv: forçar D3D11VA/NVDEC em
            // todos os codecs (2.3.0) fechava o app em notebooks com placa
            // dedicada, e só parava abrindo pela placa integrada.
            ("hwdec", hwdec_escolhido()),
            // Ao vivo: perder quadro é melhor que atrasar a imagem.
            ("profile", "low-latency"),
            ("cache", "yes"),
            ("cache-pause-initial", "no"),
            ("demuxer-max-bytes", "64MiB"),
            ("network-timeout", "20"),
            ("user-agent", crate::AGENTE),
            // Há origem que recusa quem não manda "Accept": o EmbedPlayer, dos
            // doramas e animes novos, responde 200 com "security error" no
            // lugar da playlist.
            ("http-header-fields", "Accept: */*"),
            // O EmbedPlayer serve os pedaços do HLS com extensão ".js", e o
            // FFmpeg os recusa por isso: "not in allowed_segment_extensions".
            // Sem estas duas opções a duração do filme sai vazia — e é dela
            // que depende guardar onde a pessoa parou.
            ("demuxer-lavf-o-add", "allowed_segment_extensions=ALL"),
            ("demuxer-lavf-o-add", "extension_picky=0"),
            ("tls-verify", "no"),
            ("keep-open", "no"),
            ("idle", "yes"),
            ("osc", "no"),
            ("input-default-bindings", "no"),
            ("terminal", "no"),
            // O quadro de "tocando agora" do Windows é do app (`midia.rs`),
            // com a logo e o nome do canal; o do mpv só saberia o endereço.
            ("media-controls", "no"),
        ];
        for (nome, valor) in opcoes {
            let n = CString::new(nome).unwrap();
            let v = CString::new(valor).unwrap();
            unsafe { (simbolos.set_option_string)(handle, n.as_ptr(), v.as_ptr()) };
        }
        for (nome, valor) in extras {
            let n = CString::new(*nome).unwrap();
            let v = CString::new(*valor).unwrap();
            unsafe { (simbolos.set_option_string)(handle, n.as_ptr(), v.as_ptr()); }
        }
        if unsafe { (simbolos.initialize)(handle) } < 0 {
            return Err("mpv_initialize falhou".into());
        }

        unsafe { (simbolos.request_log_messages)(handle, b"warn\0".as_ptr() as *const c_char); }
        let carregamento = Arc::new(crate::carregamento::Carregamento::default());
        let handle = Arc::new(Ponteiro(handle));
        let (emissor, avisos) = channel();
        let license=protected.then(crate::guhflix::Lease::new);
        let alive=Arc::new(Mutex::new(true));

        // Thread só para os avisos do mpv: sem ela, uma fonte morta não teria
        // como avisar a tela para pular para a próxima.
        let parar_avisos = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let thread_avisos = {
            let simbolos = simbolos.clone();
            let handle = handle.clone();
            let emissor = emissor.clone();
            let parar = parar_avisos.clone();
            let license=license.clone();
            let carregamento = carregamento.clone();
            std::thread::spawn(move || {
                let mut vigia = Vigia::default();
                loop {
                // O handle pode estar sendo destruído (fim da abertura, troca de tela): parar
                // ANTES de chamar o mpv de novo. Chamar mpv_wait_event num handle já destruído
                // corrompia a memória do processo e derrubava o app (queda no talloc do libmpv
                // e no heap do ntdll) poucos segundos depois de abrir, em alguns PCs.
                if parar.load(std::sync::atomic::Ordering::SeqCst) {
                    return;
                }
                if let Some(lease)=&license { if lease.expired(){let command=[b"stop\0".as_ptr() as *const c_char,std::ptr::null()];unsafe{(simbolos.command)(handle.0,command.as_ptr());}lease.watchdog_stop();} }
                let evento = unsafe { (simbolos.wait_event)(handle.0, 1.0) };
                if evento.is_null() {
                    continue;
                }
                let evento = unsafe { &*evento };
                if evento.event_id == EVENT_SHUTDOWN || parar.load(std::sync::atomic::Ordering::SeqCst) {
                    return;
                }
                let aviso = match evento.event_id {
                    EVENT_LOG_MESSAGE if !evento.data.is_null() => {
                        let log = unsafe { &*(evento.data as *const MpvEventLogMessage) };
                        if !log.text.is_null() {
                            let texto = unsafe { CStr::from_ptr(log.text) }.to_string_lossy();
                            if let Some(resumo) = crate::carregamento::resumir_log(&texto) {
                                crate::diagnostico::etapa(&format!("mpv: {resumo}"));
                                carregamento.falha(carregamento.id(), resumo);
                            }
                        }
                        None
                    }
                    EVENT_START_FILE if !evento.data.is_null() => {
                        let inicio = unsafe { &*(evento.data as *const MpvEventStartFile) };
                        vigia.comecou(inicio.playlist_entry_id);
                        None
                    }
                    EVENT_END_FILE if !evento.data.is_null() => {
                        let fim = unsafe { &*(evento.data as *const MpvEventEndFile) };
                        let aviso = vigia.acabou(fim.playlist_entry_id, fim.reason);
                        if aviso == Some(Aviso::Falhou) && carregamento.ultimo_erro().is_none() {
                            let texto = unsafe { (simbolos.error_string)(fim.error) };
                            let descricao = if texto.is_null() { "erro desconhecido".into() }
                                else { unsafe { CStr::from_ptr(texto) }.to_string_lossy().into_owned() };
                            let resumo = format!("Player retornou {}: {descricao}", fim.error);
                            crate::diagnostico::etapa(&format!("mpv: {resumo}"));
                            carregamento.falha(carregamento.id(), resumo);
                        }
                        aviso
                    }
                    EVENT_FILE_LOADED | EVENT_PLAYBACK_RESTART => Some(Aviso::Tocando),
                    _ => None,
                };
                if let Some(aviso) = aviso {
                    if emissor.send(aviso).is_err() {
                        return;
                    }
                }
                }
            })
        };

        Ok(Mpv {
            license,alive,carregamento,
            id: PROXIMO_ID.fetch_add(1, std::sync::atomic::Ordering::SeqCst),
            simbolos,
            handle,
            render: Mutex::new(None),
            erro_render: Mutex::new(None),
            avisos,
            _emissor: emissor,
            parar_avisos,
            thread_avisos: Mutex::new(Some(thread_avisos)),
        })
    }

    /// Liga o mpv ao contexto OpenGL da janela. Só pode ser chamado na thread
    /// que desenha.
    pub fn ligar_video(&self) -> Result<(), String> {
        let mut render = self.render.lock().unwrap();
        if render.is_some() {
            return Ok(());
        }
        let mut init = MpvOpenGLInitParams {
            get_proc_address: endereco_gl,
            get_proc_address_ctx: std::ptr::null_mut(),
        };
        let api = CString::new("opengl").unwrap();
        let mut params = [
            MpvRenderParam { tipo: PARAM_API_TYPE, dados: api.as_ptr() as *mut c_void },
            MpvRenderParam {
                tipo: PARAM_OPENGL_INIT_PARAMS,
                dados: &mut init as *mut _ as *mut c_void,
            },
            MpvRenderParam { tipo: PARAM_INVALID, dados: std::ptr::null_mut() },
        ];
        let mut contexto: *mut mpv_render_context = std::ptr::null_mut();
        let erro = unsafe {
            (self.simbolos.render_context_create)(&mut contexto, self.handle.0, params.as_mut_ptr())
        };
        if erro < 0 || contexto.is_null() {
            let mensagem = format!("mpv_render_context_create falhou ({erro})");
            *self.erro_render.lock().unwrap() = Some(mensagem.clone());
            return Err(mensagem);
        }
        *self.erro_render.lock().unwrap() = None;
        *render = Some(Render(contexto));
        Ok(())
    }

    pub fn erro_de_video(&self) -> Option<String> {
        self.erro_render.lock().unwrap().clone()
    }

    /// Desenha o quadro atual no framebuffer que já está ligado.
    pub fn desenhar(&self, fbo: i32, largura: i32, altura: i32) {
        let render = self.render.lock().unwrap();
        let Some(contexto) = render.as_ref() else { return };
        let mut alvo = MpvOpenGLFbo { fbo, w: largura, h: altura, internal_format: 0 };
        // A imagem sai de cabeça para baixo sem isto: o OpenGL conta a altura
        // de baixo para cima, e o egui de cima para baixo.
        let mut inverter: c_int = 1;
        let mut params = [
            MpvRenderParam { tipo: PARAM_OPENGL_FBO, dados: &mut alvo as *mut _ as *mut c_void },
            MpvRenderParam { tipo: PARAM_FLIP_Y, dados: &mut inverter as *mut _ as *mut c_void },
            MpvRenderParam { tipo: PARAM_INVALID, dados: std::ptr::null_mut() },
        ];
        unsafe { (self.simbolos.render_context_render)(contexto.0, params.as_mut_ptr()) };
    }

    pub fn tocar(&self, url: &str, referer: Option<&str>, agente: Option<&str>) {
        crate::diagnostico::etapa("mpv: abrindo um título");
        self.tocar_com_legenda(url, referer, agente, None);
    }

    pub fn id(&self) -> u64 {
        self.id
    }

    /// Ao vivo: a lista passa pela régua do Saimo Connect (`connect::hls`),
    /// a mesma que o celular lê, para o som no celular tocar junto com a
    /// imagem daqui. Os pedaços continuam vindo direto da origem. Sem o
    /// Connect no ar, ou fora do HLS, toca direto como sempre.
    ///
    /// `rebase-start-time=no` só neste arquivo: a posição (`time-pos`) fica no
    /// carimbo de tempo dos próprios pedaços, que é como o app a leva para a
    /// régua comum.
    pub fn tocar_ao_vivo(&self, url: &str, referer: Option<&str>, agente: Option<&str>) {
        crate::diagnostico::etapa("mpv: abrindo um canal ao vivo");
        match crate::connect::pela_regua(url, referer, agente, self.id) {
            Some(local) => self.carregar(&local, url, referer, agente, None, &["rebase-start-time=no"]),
            None => self.tocar(url, referer, agente),
        }
    }

    /// Como `tocar`, com uma legenda externa (arquivo .srt) já ligada à
    /// abertura. Trocar de fonte do mesmo título passa por aqui: a legenda
    /// escolhida acompanha, e não some junto com o arquivo anterior.
    pub fn tocar_com_legenda(&self, url: &str, referer: Option<&str>, agente: Option<&str>, legenda: Option<&str>) {
        self.carregar(url, url, referer, agente, legenda, &[]);
    }

    /// Abre `endereco`; `original` é o endereço da fonte (o mesmo, fora da
    /// régua), que decide as opções.
    fn carregar(&self, endereco: &str, original: &str, referer: Option<&str>, agente: Option<&str>, legenda: Option<&str>, extras: &[&str]) {
        self.propriedade("referrer", referer.unwrap_or(""));
        self.propriedade("user-agent", agente.unwrap_or(crate::AGENTE));
        // O atraso da legenda é do arquivo: o próximo recomeça no original.
        self.propriedade("sub-delay", "0");
        let mut opcoes: Vec<String> = extras.iter().map(|o| o.to_string()).collect();
        // Alguns masters HLS são servidos como text/plain e terminam em .txt.
        // Sem a opção por arquivo o FFmpeg os detecta como terminal ANSI e o
        // MPV nunca chega às variantes, áudios ou legendas.
        if original.split('?').next().unwrap_or(original).to_ascii_lowercase().ends_with(".txt") {
            opcoes.push("demuxer-lavf-format=hls".to_string());
        }
        if let Some(caminho) = legenda {
            // %N%valor: o caminho pode ter vírgula ou dois-pontos (C:\...).
            opcoes.push(format!("sub-files=%{}%{}", caminho.len(), caminho));
        }
        if opcoes.is_empty() {
            self.comando(&["loadfile", endereco, "replace"]);
        } else {
            self.comando(&["loadfile", endereco, "replace", "-1", &opcoes.join(",")]);
        }
    }

    /// Liga uma legenda externa ao que já está tocando e a seleciona.
    pub fn legenda_externa(&self, caminho: &str, titulo: &str, idioma: &str) {
        self.comando(&["sub-add", caminho, "select", titulo, idioma]);
    }

    /// Adianta (negativo) ou atrasa (positivo) a legenda, em segundos.
    pub fn atraso_da_legenda(&self, segundos: f64) {
        self.propriedade("sub-delay", &format!("{segundos:.2}"));
    }

    /// Faixas que o MPV encontrou no master (variantes de vídeo, idiomas e
    /// legendas). Os nomes vêm do próprio manifesto quando existem.
    pub fn faixas(&self, tipo: &str) -> Vec<Faixa> {
        let total = self.ler("track-list/count").and_then(|v| v.parse::<usize>().ok()).unwrap_or(0);
        (0..total).filter_map(|i| {
            if self.ler(&format!("track-list/{i}/type")).as_deref() != Some(tipo) { return None; }
            let id = self.ler(&format!("track-list/{i}/id"))?;
            let idioma = self.ler(&format!("track-list/{i}/lang")).unwrap_or_default();
            let nome = self.ler(&format!("track-list/{i}/title")).unwrap_or_default();
            let altura = self.ler(&format!("track-list/{i}/demux-h")).unwrap_or_default();
            let titulo = if tipo == "video" && !altura.is_empty() && altura != "0" {
                format!("{altura}p")
            } else if !nome.is_empty() && !idioma.is_empty() {
                format!("{nome} · {idioma}")
            } else if !nome.is_empty() {
                nome
            } else if !idioma.is_empty() {
                idioma
            } else {
                format!("Faixa {id}")
            };
            let selecionada = self.ler(&format!("track-list/{i}/selected")).as_deref() == Some("yes");
            Some(Faixa { id, titulo, selecionada })
        }).collect()
    }

    pub fn escolher_faixa(&self, tipo: &str, id: Option<&str>) {
        let propriedade = match tipo { "video" => "vid", "audio" => "aid", "sub" => "sid", _ => return };
        self.propriedade(propriedade, id.unwrap_or(if tipo == "sub" { "no" } else { "auto" }));
    }

    /// Pula para um ponto do arquivo (em segundos).
    pub fn ir_para(&self, segundos: f64) {
        self.comando(&["seek", &format!("{segundos:.0}"), "absolute"]);
    }

    /// Posição e duração do que está tocando, quando o mpv já sabe.
    /// Onde o vídeo está e quanto dura. Duração 0 quando a fonte não a diz —
    /// canal ao vivo, e também o HLS de origem que não declara o fim.
    pub fn posicao(&self) -> Option<(f64, f64)> {
        let posicao = self.ler("time-pos")?.parse::<f64>().ok()?;
        let duracao = self
            .ler("duration")
            .and_then(|d| d.parse::<f64>().ok())
            .filter(|d| *d > 0.0)
            .unwrap_or(0.0);
        Some((posicao, duracao))
    }

    pub fn parar(&self) {
        self.comando(&["stop"]);
    }

    pub fn pausa(&self, pausado: bool) {
        self.propriedade("pause", if pausado { "yes" } else { "no" });
    }

    pub fn volume(&self, valor: i32) {
        self.propriedade("volume", &valor.to_string());
    }

    pub fn mudo(&self, calado: bool) {
        self.propriedade("mute", if calado { "yes" } else { "no" });
    }

    /// Texto de uma propriedade do mpv, ou nada quando ela não existe agora.
    pub fn ler(&self, nome: &str) -> Option<String> {
        let n = CString::new(nome).ok()?;
        unsafe {
            let bruto = (self.simbolos.get_property_string)(self.handle.0, n.as_ptr());
            if bruto.is_null() {
                return None;
            }
            let texto = CStr::from_ptr(bruto).to_string_lossy().into_owned();
            (self.simbolos.free)(bruto as *mut c_void);
            Some(texto)
        }
    }

    pub fn avisos(&self) -> impl Iterator<Item = Aviso> + '_ {
        self.avisos.try_iter()
    }

    /// Qualquer propriedade do mpv ("speed", "panscan"…).
    pub fn definir(&self, nome: &str, valor: &str) {
        self.propriedade(nome, valor);
    }

    fn propriedade(&self, nome: &str, valor: &str) {
        let (Ok(n), Ok(v)) = (CString::new(nome), CString::new(valor)) else { return };
        unsafe { (self.simbolos.set_property_string)(self.handle.0, n.as_ptr(), v.as_ptr()) };
    }

    pub fn tempo_de_carregamento(&self) -> Option<std::time::Duration> {
        self.carregamento.tempo()
    }

    pub fn ultimo_erro_de_reproducao(&self) -> Option<String> {
        self.carregamento.ultimo_erro()
    }

    fn comando(&self, partes: &[&str]) {
        if partes.first() == Some(&"loadfile") {
            let pedido = self.carregamento.solicitar();
            crate::diagnostico::etapa("mpv: pedido de abertura registrado");
            let owned: Vec<String> = partes.iter().map(|s| s.to_string()).collect();
            let symbols = self.simbolos.clone();
            let handle = self.handle.clone();
            let clock = self.carregamento.clone();
            let sender = self._emissor.clone();
            let dispatch = move || {
                if !clock.despachar(pedido) { return; }
                let texts: Result<Vec<CString>, _> = owned.iter().map(|s| CString::new(s.as_str())).collect();
                let Ok(texts) = texts else {
                    clock.falha(pedido, "Endereço de vídeo inválido.".into());
                    let _ = sender.send(Aviso::Falhou);
                    return;
                };
                let mut args: Vec<*const c_char> = texts.iter().map(|s| s.as_ptr()).collect();
                args.push(std::ptr::null());
                let result = unsafe { (symbols.command)(handle.0, args.as_ptr()) };
                crate::diagnostico::etapa(&format!("mpv: abertura despachada ao player; resultado {result}"));
                if result < 0 {
                    let ptr = unsafe { (symbols.error_string)(result) };
                    let desc = if ptr.is_null() { "erro desconhecido".into() }
                        else { unsafe { CStr::from_ptr(ptr) }.to_string_lossy().into_owned() };
                    clock.falha(pedido, format!("Comando de abertura retornou {result}: {desc}"));
                    let _ = sender.send(Aviso::Falhou);
                }
            };
            if let Some(lease) = &self.license { lease.load(self.alive.clone(), dispatch); }
            else { dispatch(); }
            return;
        }
        if partes.first() == Some(&"stop") {
            self.carregamento.solicitar();
            if let Some(lease) = &self.license { lease.stop(); }
        }
        let textos: Vec<CString> = partes.iter().filter_map(|p| CString::new(*p).ok()).collect();
        let mut ponteiros: Vec<*const c_char> = textos.iter().map(|t| t.as_ptr()).collect();
        ponteiros.push(std::ptr::null());
        unsafe { (self.simbolos.command)(self.handle.0, ponteiros.as_ptr()) };
    }

}

impl Drop for Mpv {
    fn drop(&mut self) {
        *self.alive.lock().unwrap()=false;
        if let Some(lease)=&self.license{lease.stop();}
        crate::diagnostico::etapa("mpv: encerrando um player");
        // 1) A thread dos avisos sai do mpv_wait_event (o wakeup o devolve na hora) e termina;
        //    só então o handle pode ser destruído.
        self.parar_avisos.store(true, std::sync::atomic::Ordering::SeqCst);
        unsafe { (self.simbolos.wakeup)(self.handle.0) };
        if let Some(t) = self.thread_avisos.lock().ok().and_then(|mut g| g.take()) {
            let _ = t.join();
        }
        // 2) O contexto de vídeo antes do player (ordem exigida pelo libmpv).
        if let Some(render) = self.render.lock().unwrap().take() {
            unsafe { (self.simbolos.render_context_free)(render.0) };
        }
        // 3) O player.
        unsafe { (self.simbolos.terminate_destroy)(self.handle.0) };
        crate::diagnostico::etapa("mpv: player encerrado");
    }
}

#[cfg(test)]
mod testes {
    use super::*;

    const STOP: c_int = 2;
    const REDIRECT: c_int = 5;

    #[test]
    fn trocar_de_fonte_nao_derruba_a_nova() {
        // Canal A tocando (item 1); o app manda tocar B (item 2). O mpv avisa,
        // nesta ordem: B começou, A acabou por STOP.
        let mut v = Vigia::default();
        v.comecou(1);
        v.comecou(2);
        assert_eq!(v.acabou(1, STOP), None);
        // Mesmo um erro atrasado do arquivo antigo não conta.
        assert_eq!(v.acabou(1, END_FILE_ERROR), None);
    }

    #[test]
    fn stop_do_proprio_arquivo_nao_e_queda() {
        let mut v = Vigia::default();
        v.comecou(7);
        assert_eq!(v.acabou(7, STOP), None);
        assert_eq!(v.acabou(7, REDIRECT), None);
    }

    #[test]
    fn erro_e_fim_do_arquivo_no_ar_contam() {
        let mut v = Vigia::default();
        v.comecou(3);
        assert_eq!(v.acabou(3, END_FILE_ERROR), Some(Aviso::Falhou));
        assert_eq!(v.acabou(3, END_FILE_EOF), Some(Aviso::Fim));
    }

    #[test]
    fn rajada_de_trocas_so_ouve_a_ultima() {
        // Pular canais depressa: cinco loadfile seguidos.
        let mut v = Vigia::default();
        for item in 1..=5 {
            v.comecou(item);
        }
        for antigo in 1..5 {
            assert_eq!(v.acabou(antigo, STOP), None);
        }
        assert_eq!(v.acabou(5, END_FILE_ERROR), Some(Aviso::Falhou));
    }
}

#[cfg(all(test, windows))]
mod integracao {
    use super::*;
    use std::{io::{Read, Write}, net::{TcpListener, TcpStream}, sync::atomic::{AtomicBool, AtomicUsize, Ordering}, time::{Duration, Instant}};

    struct Fixture {
        url: String,
        stop: Arc<AtomicBool>,
        requests: Arc<AtomicUsize>,
        join: Option<std::thread::JoinHandle<()>>,
    }
    impl Fixture {
        fn nova() -> Self {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let address = listener.local_addr().unwrap();
            listener.set_nonblocking(true).unwrap();
            let stop = Arc::new(AtomicBool::new(false));
            let requests = Arc::new(AtomicUsize::new(0));
            let quit = stop.clone();
            let counter = requests.clone();
            let join = std::thread::spawn(move || {
                while !quit.load(Ordering::SeqCst) {
                    let (mut stream, _) = match listener.accept() {
                        Ok(v) => v,
                        Err(_) => { std::thread::sleep(Duration::from_millis(10)); continue; }
                    };
                    stream.set_read_timeout(Some(Duration::from_secs(2))).unwrap();
                    let mut data = Vec::new();
                    let mut buf = [0u8; 2048];
                    while !data.windows(4).any(|w| w == b"\r\n\r\n") && data.len() < 16000 {
                        match stream.read(&mut buf) { Ok(0) | Err(_) => break, Ok(n) => data.extend_from_slice(&buf[..n]) }
                    }
                    let head = String::from_utf8_lossy(&data);
                    let path = head.lines().next().and_then(|s| s.split_whitespace().nth(1)).unwrap_or("");
                    let content: Option<&[u8]> = match path {
                        "/manifest.txt" => Some(include_bytes!("../assets/test-hls/manifest.txt")),
                        "/segment-00.js" => Some(include_bytes!("../assets/test-hls/segment-00.js")),
                        "/segment-01.js" => Some(include_bytes!("../assets/test-hls/segment-01.js")),
                        "/segment-02.js" => Some(include_bytes!("../assets/test-hls/segment-02.js")),
                        "/segment-03.js" => Some(include_bytes!("../assets/test-hls/segment-03.js")),
                        _ => None,
                    };
                    if let Some(body) = content {
                        // Confere os mesmos cabeçalhos usados pelo aplicativo original.
                        assert!(head.contains(crate::AGENTE), "user-agent diferente do Saímo");
                        assert!(head.to_ascii_lowercase().contains("accept: */*"));
                        counter.fetch_add(1, Ordering::SeqCst);
                        let _ = write!(stream, "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: {}\r\nConnection: close\r\n\r\n", body.len());
                        let _ = stream.write_all(body);
                    } else {
                        let _ = stream.write_all(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
                    }
                }
            });
            Self { url: format!("http://{address}"), stop, requests, join: Some(join) }
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            self.stop.store(true, Ordering::SeqCst);
            if let Some(join) = self.join.take() { let _ = join.join(); }
        }
    }

    #[test]
    #[ignore = "requer a DLL original: executado explicitamente pelo workflow Windows"]
    fn mpv_integracao_hls_com_dll_original() {
        let path = std::env::var("GUHFLIX_TEST_MPV_DLL").expect("DLL original ausente no teste");
        let fixture = Fixture::nova();
        // Somente neste teste de mídia sintética: sem janela/dispositivo de áudio.
        // Não é um caminho alternativo para reprodução de catálogo no aplicativo.
        let mpv = Mpv::new_with_options(std::path::Path::new(&path), false,
            &[("vo", "null"), ("ao", "null"), ("hwdec", "no")]).unwrap();
        mpv.tocar(&format!("{}/manifest.txt", fixture.url), None, None);
        let start = Instant::now();
        let mut tocou = false;
        while start.elapsed() < Duration::from_secs(12) {
            for aviso in mpv.avisos() {
                assert_ne!(aviso, Aviso::Falhou, "erro: {:?}", mpv.ultimo_erro_de_reproducao());
                if aviso == Aviso::Tocando { tocou = true; }
            }
            if tocou && mpv.ler("time-pos").and_then(|s| s.parse::<f64>().ok()).is_some_and(|p| p > 0.2) { break; }
            std::thread::sleep(Duration::from_millis(30));
        }
        assert!(tocou, "o HLS não carregou: {:?}", mpv.ultimo_erro_de_reproducao());
        let pos = mpv.ler("time-pos").and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
        assert!(pos > 0.2, "a posição não avançou: {pos}");
        assert!(fixture.requests.load(Ordering::SeqCst) >= 2, "playlist e segmento não foram lidos");
        assert!(mpv.tempo_de_carregamento().is_some());
        mpv.parar();
        assert!(mpv.tempo_de_carregamento().is_none());
        let _ = mpv.avisos().collect::<Vec<_>>();
        mpv.tocar(&format!("{}/inexistente.m3u8", fixture.url), None, None);
        let began = Instant::now();
        let mut falhou = false;
        while began.elapsed() < Duration::from_secs(8) {
            if mpv.avisos().any(|a| a == Aviso::Falhou) { falhou = true; break; }
            std::thread::sleep(Duration::from_millis(30));
        }
        assert!(falhou, "o player não informou o erro HTTP");
        let erro = mpv.ultimo_erro_de_reproducao().expect("erro real do player não foi capturado");
        assert!(!erro.contains("http://"));
        println!("PASS: HLS .txt + segmentos .js abriu e avançou {pos:.2}s com a DLL original; erro HTTP capturado: {erro}");
        mpv.parar();
    }
}
